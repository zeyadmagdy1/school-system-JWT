﻿using minimal_school_system.Models;

namespace minimal_school_system.SubjectRepo
{
    public interface ISubjectReposatory
    {
        public void AddSubject(SubjectDto subject);


        public List<Subject> GetSubjects();
    }
}