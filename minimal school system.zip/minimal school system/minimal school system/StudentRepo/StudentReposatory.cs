﻿using Microsoft.EntityFrameworkCore;
using minimal_school_system.Data;
using minimal_school_system.Models;

namespace minimal_school_system.Reposatory_Patterns
{
    public class StudentReposatory : IStudentReposatory
    {
        private readonly AppDbContext _context;
        public StudentReposatory(AppDbContext context) {
            _context = context;
        }
        public void AddStudent(StudentDto student)
        {
            Student student1 = new Student {
                Email = student.Email,
                Name = student.Name,
                Password = student.Password,
                SubjectId = student.SubjectId,
                Username = student.Username
            };
            _context.students.Add(student1);
            _context.SaveChanges();
        }

        public void DeleteStudent(int id)
        {
            var result = _context.students.FirstOrDefault(x => x.StudentId == id);
            _context.students.Remove(result);
            _context.SaveChanges();
        }

        public List<StudentDto> GetStudents()
        {
            var result= _context.students.Include(i => i.Subject).Select( i => new StudentDto {
                SubjectId = i.SubjectId,
                Email = i.Email,
                Name = i.Name,
                Password = i.Password,
                Username = i.Username,
                SubjectName =i.Subject.SubjectName
            }).ToList();

            return result;
        }

        public Student GetStudnet(int id)
        {
            var result = _context.students.FirstOrDefault(x => x.StudentId == id);
            return result;
        }

        public void UpdateStudent( int id, string username)
        {
            var result = _context.students.FirstOrDefault(x => x.StudentId == id);
            result.Username = username;
            _context.SaveChanges();
        }
    }
}
