﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using minimal_school_system.Data;
using minimal_school_system.JWT;
using minimal_school_system.Models;
using minimal_school_system.Reposatory_Patterns;
using System.ComponentModel.DataAnnotations;

namespace minimal_school_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentReposatory _context;
        private readonly IJwtHandler _jwtHandler;
        public StudentController(IStudentReposatory context,IJwtHandler jwtHandler) 
        { 
            _context = context;
            _jwtHandler = jwtHandler;
        }
        [HttpGet]
        [Authorize]
        public IActionResult GetAllStudents()
        {
            var result = _context.GetStudents();
            return Ok(result);
        }

       [HttpPost]
        public IActionResult AddStudent([FromQuery] StudentDto student)
        {
            _context.AddStudent(student);
            var token = _jwtHandler.GenerateJwtToken();
            return Ok(token);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteStudent([FromRoute]int id)
        {
            _context.DeleteStudent(id);
            return Ok();
        }
        [HttpPut("{id}")]
        public IActionResult UpdateStudent(int id , string username)
        {
            _context.UpdateStudent(id, username);
            return Ok();
        }
        [HttpGet("{id}")]
        [Authorize]
        public IActionResult GetStudent(int id)
        {
            var result = _context.GetStudnet(id);
            return Ok(result);
        }
    }
}
