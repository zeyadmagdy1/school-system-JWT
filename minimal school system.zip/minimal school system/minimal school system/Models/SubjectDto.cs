﻿namespace minimal_school_system.Models
{
    public class SubjectDto
    {
        public string Name { get; set; }
    }
}
