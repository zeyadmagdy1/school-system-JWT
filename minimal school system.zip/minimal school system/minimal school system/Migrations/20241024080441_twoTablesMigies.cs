﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace minimal_school_system.Migrations
{
    /// <inheritdoc />
    public partial class twoTablesMigies : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_students_instractorrs_InstractorrId",
                table: "students");

            migrationBuilder.DropTable(
                name: "instractorrs");

            migrationBuilder.DropIndex(
                name: "IX_students_InstractorrId",
                table: "students");

            migrationBuilder.DropColumn(
                name: "InstractorrId",
                table: "students");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "InstractorrId",
                table: "students",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "instractorrs",
                columns: table => new
                {
                    InstractorrId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubjectId = table.Column<int>(type: "int", nullable: false),
                    InstractorName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InstractorSalary = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_instractorrs", x => x.InstractorrId);
                    table.ForeignKey(
                        name: "FK_instractorrs_subjects_SubjectId",
                        column: x => x.SubjectId,
                        principalTable: "subjects",
                        principalColumn: "SubjectId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_students_InstractorrId",
                table: "students",
                column: "InstractorrId");

            migrationBuilder.CreateIndex(
                name: "IX_instractorrs_SubjectId",
                table: "instractorrs",
                column: "SubjectId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_students_instractorrs_InstractorrId",
                table: "students",
                column: "InstractorrId",
                principalTable: "instractorrs",
                principalColumn: "InstractorrId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
