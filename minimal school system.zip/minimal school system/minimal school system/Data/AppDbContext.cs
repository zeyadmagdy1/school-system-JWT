﻿using Microsoft.EntityFrameworkCore;
using minimal_school_system.Models;

namespace minimal_school_system.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Student>()
            //    .HasOne(s => s.Subject)
            //    .WithMany(sub => sub.Students)
            //    .HasForeignKey(s => s.SubjectId)
            //    .OnDelete(DeleteBehavior.Restrict); // Prevent cascade delete

            //modelBuilder.Entity<Instractorr>()
            //    .HasMany(i => i.students)
            //    .WithMany(s => s.Instractorr)
            //    .UsingEntity(j => j.ToTable("InstructorStudent"));

            // Configure other relationships similarly
        }

        public DbSet<Student> students { get; set; }

        public DbSet<Subject> subjects { get; set; }    

    }
}
